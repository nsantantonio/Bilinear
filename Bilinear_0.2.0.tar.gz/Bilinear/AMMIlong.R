##########################################
##########################################
#### AMMI variance components example ####
##########################################
##########################################

library(Bilinear)

# Here is our example soy data set.
data(soy) 
print(soy) # this is a table of genotype means within environment

anova(lm(y ~ E + E:block + G + G:E, data = soy))
fullAMMIfit <- bilinear(soy, returnDataFrame = FALSE)
fullAMMIfit$




X <- model.matrix(y ~ E + G + E:block + G:E, data = soy)
crossprod(X)

g <- nrow(soyMeanMat) # number of genotypes
e <- ncol(soyMeanMat) # number of environments

################################
#### Means and the GE table ####
################################

mu <- mean(soyMeanMat) # grand mean 
G <- rowMeans(soyMeanMat) # Genotype means
E <- colMeans(soyMeanMat) # Environment means

GE <- sweep(soyMeanMat, 2, E) # subtract E means
GE <- sweep(GE, 1, G) # subtract G means
GE <- GE + mu # add grand mean back in because we subtracted twice (i.e. it is in both G and E)

############################################
#### Singular Value Decomposition of GE ####
############################################

# lets decompose GE
# perform a singular value decomposition on the GE table of residuals from the additive model
# here, we allow GE = UDV'
UDV <- svd(GE) 
print(round(UDV$d, 10)) # these are the singular values. Ive rounded them for printing sake

#If you square them you get the eigenvaules, 
eig <- UDV$d^2
round(eig, 10)
# NOTE: notice that the last eigenvalue is 0! this means that the GE matrix is rank deficient, 
# this is because we subtracted the means (i.e. 1 dimension) out of it already

# divide the eigenvalues by (e-1)(g-1) and you get the variance components for each IPC
VarIPC <- eig / ((e - 1) * (g - 1))
print(round(VarIPC), 10)

#############################
#### Dimensions and IPCs ####
#############################

# Ok, here is our problem. We want to partition some to GxE and some to noise. 
# We want to pick the largest IPCs and attribute them to GxE and leave the remaining smaller IPCs to "noise"
# The first thing we could do is assign 0 IPcs to GxE (i.e. its all noise), This would be an AMMI0
varGxE <- 0
varResid <- sum(VarIPC)
print(round(c(sigmasqGxE = varGxE, sigmasqR = varResid), 10))

# Ok thats not useful, unless there truely is no signal

# What if we assign all but the "last IPC" to GxE? Well lets see:
print(length(VarIPC)) # note there are "7" variance components, but its actually only 6 because the last one is always 0
varGxE <- sum(VarIPC[1:6]) # sum the first 6 variance components
varResid <- VarIPC[7] # put the last variance component to the residual
# now lets have a look, at the AMMI6
print(round(c(sigmasqGxE = varGxE, sigmasqR = varResid), 10))
# You can see that we put all the variance to GxE, which is essentially what we started with.

# to see this lets reform the GE table from the decomposition, but only use the 
# first 6, instead of 7 dimensions (remember the last one is 0)
newGE <- UDV$u[, 1:6] %*% diag(UDV$d[1:6]) %*% t(UDV$v[, 1:6]) # reform GE with only first 6 IPCs
round(GE - newGE, 10) # ok, all zeros, so we did nothing here, we simply reassigned all the variance to GxE


# So we cant assign no IPCs to GxE, because then we assign it all to "residual",
# and we cant assign all but the last IPC (first 6) to GxE, because the last IPC is really 0

# therefore we must choose between 1 IPC and 5 IPCs to assign to GxE 
# and the remaining (i.e. 6 to 2 IPCs) must be assigned to the residual

############################
#### Significance Tests ####
############################

# Here is where the statistical tests come into play. 
# We want to know how many IPCs we should partition to GxE and how many to the residual 
# lets run bilinear() to test how many (k) IPCs we should include
AMMIfit <- bilinear(soyMeanMat)

# Ok, I am only going to extract the number of significant IPCs from our test
k <- AMMIfit$sigPC
print(k) # looks like we need two IPCs

#############################
#### Variance Components ####
#############################

# lets do just what we did before, only now we know how many we need
varGxE <- sum(VarIPC[1:2]) # sum the first 2 variance components
varResid <- sum(VarIPC[3:7]) # put the last 5 variance component to the residual

# now lets have a look at the AMMI2 variance components
print(round(c(sigmasqGxE = varGxE, sigmasqR = varResid), 10))

# Do they match our AMMI analysis?
print(AMMIfit$varcomp) # Yup!

###############
#### ANOVA ####
###############

# lets have a look at the ANOVA table from bilinear()
print(AMMIfit$ANOVA)
# notice there are only 5 IPCs listed. This is because at least one 
# non-zero IPC must be partitioned to the residual, or else we havent 
# done anything by partitioning
# The 6th IPC is called the residual here, and the 7th IPC is not shown because it is always 0. 

# because we determine that only the first two belong in GxE, we could sum their sums of squares
SSgxe <- sum(AMMIfit$ANOVA[c("PC1", "PC2"), "SS"])

# we could also sum the residual SS and the remaining IPC SS to get the total residual SS (i.e. noise SS)
SSnoise <- sum(AMMIfit$ANOVA[c("PC3", "PC4", "PC5", "Residuals"), "SS"])

# We could take a ratio of these if we wanted:
SSgxe / (SSgxe + SSnoise) # however I think it is not clear yet what this ratio is

# So what are these SS?
print(AMMIfit$ANOVA[c("PC1", "PC2", "PC3", "PC4", "PC5", "Residuals"), "SS"])
# we've seen these before!

print(round(eig, 3)) # they are just the eigen values

# So what are the eigen values anyway?
# they are proportional to the variance components as we saw before.
eig / VarIPC # all 54, i.e. df = (e - 1) * (g - 1)

# So what if we looked at the sum of the variance components 
# attributed to GxE and the sum attributed to the residual, 
# and then took a ratio

varGxE / (varGxE + varResid) # exactly the same as our sums of squares ratio.
# this is simply the proportion of the interaction we attributed to GxE

###################
#### Estimates ####
###################

# Lets form the GxE matrix with just the first 2 IPCs from the GE table
GxE <- UDV$u[, 1:2] %*% diag(UDV$d[1:2]) %*% t(UDV$v[, 1:2]) # reform GE with only first 2 IPCs
round(GE - GxE, 10) # ok, these are not all zero, so we did something here. 

# Lets make the residuals
R <- UDV$u[, 3:7] %*% diag(UDV$d[3:7]) %*% t(UDV$v[, 3:7]) # reform GE with only first 2 IPCs
round(GE - R, 10) 


# So GxE and R should sum to the original GE table
round(GE - (GxE + R), 10)  # Good!

# if we wanted to obtain our new AMMI2 estimates of genotype performance within environment
# we want to sum the genotype and environment main effects, as well as the new GxE table
# intentionally leaving the Residual out

Gmat <- matrix(G, g, e) # put the genotype means into a matrix
Emat <- matrix(E, g, e, byrow = TRUE) # put the environment means into a matrix
# make the new estimates of genotype within environment
yhat <- Emat + Gmat + GxE - mu  

# compare them in a plot
plot(soyMeanMat, yhat)

# Note we didnt chnage the values much, even though we only used the first 2 IPCs.
# this is due to the structure of the decomposition, and will be different for other data sets





