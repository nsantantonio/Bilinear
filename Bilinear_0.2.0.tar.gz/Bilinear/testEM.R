nMiss <- 10 
Ytrue <- soyMeanMat
Y <- soyMeanMat
Y[sample(1:prod(dim(Y)), nMiss)] <- NA
k <- NULL
# EM(Y, tol = 1e-2, fast = 2)
EM(Y, model = "AMMI", tol = 1e-5, fast = TRUE, k = 2, Ytrue = Ytrue, plotMSE = TRUE)

nT <- 20
missG <- list()
missE <- list()
MSEreduce <- NULL
for(i in 1:nT){
	nMiss <- 10 
	Ytrue <- soyMeanMat
	Y <- soyMeanMat
	Y[sample(1:prod(dim(Y)), nMiss)] <- NA

	whichMiss <- which(is.na(Y), arr.ind = TRUE)
	# EM(Y, tol = 1e-2, fast = 2)
	# imputed <- EM(Y, model = "AMMI", tol = 1e-5, fast = TRUE, k = 2, Ytrue = Ytrue, plotMSE = TRUE)
	imputed <- EM(Y, model = "AMMI", tol = 1e-5, fast = 2, Ytrue = Ytrue, plotMSE = TRUE)
	mse <- imputed$MSE
	missG[[i]] <- table(factor(rownames(Y)[whichMiss[, 1]], levels = rownames(Y)))
	missE[[i]] <- table(factor(colnames(Y)[whichMiss[, 2]], levels = colnames(Y)))
	MSEreduce[i] <- mse[[length(mse)]] / mse[[1]]
}

sum(MSEreduce > 1)
colSums(do.call(rbind, missG[MSEreduce > 1]))
colSums(do.call(rbind, missE[MSEreduce > 1]))
