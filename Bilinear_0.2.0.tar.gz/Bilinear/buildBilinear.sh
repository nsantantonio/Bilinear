R -e 'library(devtools);document()'
cd ..
R CMD build Bilinear
R CMD INSTALL Bilinear
cd Bilinear